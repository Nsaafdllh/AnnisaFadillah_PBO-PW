const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../config/db");
const router = express.Router();

router.get("/index", (req, res) => {
  if (req.session.user) {
    res.render("index", { user: req.session.user });
  } else {
    res.redirect("/login");
  }
});

router.get("/login", (req, res) => {
  res.render("login");
});

router.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (err, result) => {
      if (err) throw err;

      if (result.length && bcrypt.compareSync(password, result[0].password)) {
        req.session.user = result[0];
        res.redirect("/index");
      } else {
        res.render("login", { error: "Username atau Password Salah!" });
      }
    }
  );
});

router.get("/registrasi", (req, res) => {
  res.render("registrasi");
});

router.post("/registrasi", (req, res) => {
  const { username, password, email, no_telepon, } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);

  db.query(
    "INSERT INTO users (username, password, email, no_telepon) VALUES (?, ?, ?, ?)",
    [username, hashedPassword, email, no_telepon,],
    (err, result) => {
      if (err) throw err;
      res.redirect("/login");
    }
  );
});

router.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.log(err);
      return res.redirect("/");
    }
    res.clearCookie("connect.sid");
    res.redirect("/login");
  });
});

module.exports = router;
